import React from 'react';

const EventTimeline = () => {
  return (
    <div>
      <h3>Event Timeline</h3>
      <p>Swap states and transitions log</p>
    </div>
  );
};

export default EventTimeline;