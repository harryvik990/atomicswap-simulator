import React from 'react';

const ContractDeployer = () => {
  return (
    <div>
      <h3>Smart Contract Deployment</h3>
      <button>Deploy SC_1 (Alice)</button>
      <button>Deploy SC_2 (Bob)</button>
    </div>
  );
};

export default ContractDeployer;