import React from 'react';

const ControlPanel = () => {
  return (
    <div>
      <h3>Control Panel</h3>
      <button>Trigger Swap</button>
      <button>Trigger Refund</button>
    </div>
  );
};

export default ControlPanel;