import React from 'react';

const SwapGraph = () => {
  return (
    <div>
      <h3>Atomic Swap Graph (AS_{A-B})</h3>
      <p>Graph visualizer placeholder</p>
    </div>
  );
};

export default SwapGraph;